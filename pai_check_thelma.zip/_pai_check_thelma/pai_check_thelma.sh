#!/bin/bash
# Verifier le stock et la date limite de consommation des médicaments du PAI

DateToday=`date +%Y-%m-%d`

echo -e "Nous sommes le :"
date +%Y-%m-%d

echo -e "\nVoici l'état du PAI de Thelma"

StockAnapen=`sed -n 5p /mnt/pi/demetrius/_pai_check_thelma/anapen`
StockCelestene=`sed -n 5p /mnt/pi/demetrius/_pai_check_thelma/celestene`
StockDesloratadine=`sed -n 5p /mnt/pi/demetrius/_pai_check_thelma/desloratadine`
StockFlixotide=`sed -n 5p /mnt/pi/demetrius/_pai_check_thelma/flixotide`
StockVentoline=`sed -n 5p /mnt/pi/demetrius/_pai_check_thelma/ventoline`

DLCAnapenEcole=`sed -n 9p /mnt/pi/demetrius/_pai_check_thelma/anapen`
DLCCelesteneEcole=`sed -n 9p /mnt/pi/demetrius/_pai_check_thelma/celestene`
DLCDesloratadineEcole=`sed -n 9p /mnt/pi/demetrius/_pai_check_thelma/desloratadine`
DLCFlixotideEcole=`sed -n 9p /mnt/pi/demetrius/_pai_check_thelma/flixotide`
DLCVentolineEcole=`sed -n 9p /mnt/pi/demetrius/_pai_check_thelma/ventoline`

DLCAnapenCentre=`sed -n 12p /mnt/pi/demetrius/_pai_check_thelma/anapen`
DLCCelesteneCentre=`sed -n 12p /mnt/pi/demetrius/_pai_check_thelma/celestene`
DLCDesloratadineCentre=`sed -n 12p /mnt/pi/demetrius/_pai_check_thelma/desloratadine`
DLCFlixotideCentre=`sed -n 12p /mnt/pi/demetrius/_pai_check_thelma/flixotide`
DLCVentolineCentre=`sed -n 12p /mnt/pi/demetrius/_pai_check_thelma/ventoline`

DLCAnapenMaison=`sed -n 15p /mnt/pi/demetrius/_pai_check_thelma/anapen`
DLCCelesteneMaison=`sed -n 15p /mnt/pi/demetrius/_pai_check_thelma/celestene`
DLCDesloratadineMaison=`sed -n 15p /mnt/pi/demetrius/_pai_check_thelma/desloratadine`
DLCFlixotideMaison=`sed -n 15p /mnt/pi/demetrius/_pai_check_thelma/flixotide`
DLCVentolineMaison=`sed -n 15p /mnt/pi/demetrius/_pai_check_thelma/ventoline`

# listing du stock

echo -e "\n-----------------------------------------"
echo -e " * STOCK"
echo -e "-----------------------------------------"
echo -e "Anapen  \t$StockAnapen"
echo -e "Celestene \t$StockCelestene"
echo -e "Desloratadine \t$StockDesloratadine"
echo -e "Flixotide \t$StockFlixotide"
echo -e "Ventoline \t$StockVentoline"

# listing DLC

echo -e "\n-----------------------------------------"
echo -e " * DATE LIMITE DE CONSOMMATION"
echo -e "-----------------------------------------"
echo -e "              \tEcole         \tCentre  \tMaison"
echo -e "Anapen  \t$DLCAnapenEcole\t$DLCAnapenCentre\t$DLCAnapenMaison"
echo -e "Celestene \t$DLCCelesteneEcole\t$DLCCelesteneCentre\t$DLCCelesteneMaison"
echo -e "Desloratadine \t$DLCDesloratadineEcole\t$DLCDesloratadineCentre\t$DLCDesloratadineMaison"
echo -e "Flixotide \t$DLCFlixotideEcole\t$DLCFlixotideCentre\t$DLCFlixotideMaison"
echo -e "Ventoline \t$DLCVentolineEcole\t$DLCVentolineCentre\t$DLCVentolineMaison"

# pointage des defauts stock

if [ $StockAnapen -lt 1 -o $StockCelestene -lt 1 -o $StockDesloratadine -lt 1 -o $StockFlixotide -lt 1 -o $StockVentoline -lt 1 ]
	then
		echo -e "\n#######################################################################"
		echo -e "   ATTENTION ! Il n'y a plus de stock pour les medicaments suivants:"
		echo -e "------------------------------------------------------------------------"
		
		
		if [ $StockAnapen -lt 1 ]
			then
				echo -e "* Anapen"
		fi  

		if [ $StockCelestene -lt 1 ]
			then
				echo -e "* Celestene"
		fi

		if [ $StockDesloratadine -lt 1 ]
			then
				echo -e "* Desloratadine"
		fi

		if [ $StockFlixotide -lt 1 ]
			then
				echo -e "* Flixotide"
		fi

		if [ $StockVentoline -lt 1 ]
			then
				echo -e "* Ventoline"
		fi
		
		echo -e "#######################################################################"
		echo -e "\nVeuillez prendre RDV avec le Docteur Delaet." && echo -e "Telephone Secretariat : 01 39 12 21 31" && echo -e "https://www.doctolib.fr/medecin-generaliste/maisons-laffitte/caroline-delaet"
        
	else
		echo -e "\nLe stock de médicament est suffisant."
		
fi


# pointage des defauts DLC

if [[ $DateToday > $DLCAnapenEcole ]] || [[ $DateToday > $DLCAnapenCentre ]] || [[ $DateToday > $DLCAnapenMaison ]] || [[ $DateToday > $DLCCelesteneEcole ]] || [[ $DateToday > $DLCCelesteneCentre ]] || [[ $DateToday > $DLCCelesteneMaison ]] || [[ $DateToday > $DLCDesloratadineEcole ]] || [[ $DateToday > $DLCDesloratadineCentre ]] || [[ $DateToday > $DLCDesloratadineMaison ]] || [[ $DateToday > $DLCFlixotideEcole ]] || [[ $DateToday > $DLCFlixotideCentre ]] || [[ $DateToday > $DLCFlixotideMaison ]] || [[ $DateToday > $DLCVentolineEcole ]] || [[ $DateToday > $DLCVentolineCentre ]] || [[ $DateToday > $DLCVentolineMaison ]]
	then
		echo -e "\n#######################################################################"
		echo -e "   ATTENTION ! Les médicaments suivants sont périmés:"
		echo -e "------------------------------------------------------------------------"

		if [[ $DateToday > $DLCAnapenEcole ]]
			then
				 echo -e "* Anapen Ecole"
		fi

		if [[ $DateToday > $DLCAnapenCentre ]]
			then
				 echo -e "* Anapen Centre"
		fi
				 
		if [[ $DateToday > $DLCAnapenMaison ]]
			then
				 echo -e "* Anapen Maison"
		fi
		
		if [[ $DateToday > $DLCCelesteneEcole ]]
			then
				 echo -e "* Celestene Ecole"
		fi

		if [[ $DateToday > $DLCCelesteneCentre ]]
			then
				 echo -e "* Celestene Centre"
		fi
				 
		if [[ $DateToday > $DLCCelesteneMaison ]]
			then
				 echo -e "* Celestene Maison"
		fi
		
		if [[ $DateToday > $DLCDelsoratadineEcole ]]
			then
				 echo -e "* Delsoratadine Ecole"
		fi

		if [[ $DateToday > $DLCDelsoratadineCentre ]]
			then
				 echo -e "* Delsoratadine Centre"
		fi
				 
		if [[ $DateToday > $DLCDelsoratadineMaison ]]
			then
				 echo -e "* Delsoratadine Maison"
		fi
		
		if [[ $DateToday > $DLCFlixotideEcole ]]
			then
				 echo -e "* Flixotide Ecole"
		fi

		if [[ $DateToday > $DLCFlixotideCentre ]]
			then
				 echo -e "* Flixotide Centre"
		fi
				 
		if [[ $DateToday > $DLCFlixotideMaison ]]
			then
				 echo -e "* Flixotide Maison"
		fi
		
		if [[ $DateToday > $DLCVentolineEcole ]]
			then
				 echo -e "* Ventoline Ecole"
		fi

		if [[ $DateToday > $DLCVentolineCentre ]]
			then
				 echo -e "* Ventoline Centre"
		fi
				 
		if [[ $DateToday > $DLCVentolineMaison ]]
			then
				 echo -e "* Ventoline Maison"
		fi
		
		echo -e "#######################################################################"
		echo -e "\nVeuillez prendre RDV avec le Docteur Delaet." && echo -e "Telephone Secretariat : 01 39 12 21 31" && echo -e "https://www.doctolib.fr/medecin-generaliste/maisons-laffitte/caroline-delaet"
		
else
	echo -e "\nAuncun médicament n'est périmé."

fi

sleep 1d
