#!/bin/bash
# demander les comportements à suivre concernant les montages distants de pegasus

if ssh osmc@192.168.0.21 [ -d "/media/pegasus/" ];then
	echo -e "Le chemin vers pegasus existe bien." && echo -e "Que souhaitez vous faire ?";

	# liste de choix disponibles
	LISTE=("[d] démonter pegasus sur osmc" "[m] lancer tous les montages auto de fstab" "[a] annuler l'opération") 
 
	select i in "${LISTE[@]}" ; do
		case $REPLY in

        		1|d)
			echo -e "\nDémontage de la connexion samba locale /mnt/osmc/pegasus initialisée" && sleep 5 && sudo umount -t -cifs /mnt/osmc/pegasus && echo -e "\nConnexion samba locale démontée." && ssh osmc@192.168.0.21 umount /media/pegasus && echo -e "\nDémontage distant effectué" && sleep 5
			break
        		;;

        		2|m)
        		sudo mount -av && sleep 10
			break
        		;;

			3|a)
        		echo -e "\nDémontage annulé" && sleep 5
			break
        		;;
    		esac

	done

else 	echo -e "\n\nLe chemin vers pegasus n'existe pas.\nDémontage annulé" && sleep 5

fi