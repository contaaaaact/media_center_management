#!/bin/bash
# demander les comportements à suivre concernant les montages distants de colonial1

if ssh osmc@192.168.0.21 [ -d "/media/colonial1/" ];then
	echo -e "Le chemin vers colonial1 existe bien." && echo -e "Que souhaitez vous faire ?";

	# liste de choix disponibles
	LISTE=("[d] démonter colonial1 sur osmc" "[m] lancer tous les montages auto de fstab" "[a] annuler l'opération") 
 
	select i in "${LISTE[@]}" ; do
		case $REPLY in

        		1|d)
			echo -e "\nDémontage de la connexion samba locale /mnt/osmc/colonial1 initialisée" && sleep 5 && sudo umount -t -cifs /mnt/osmc/colonial1 && echo -e "\nConnexion samba locale démontée." && ssh osmc@192.168.0.21 umount /media/colonial1 && echo -e "\nDémontage distant effectué" && sleep 5
			break
        		;;

        		2|m)
        		sudo mount -av && sleep 10
			break
        		;;

			3|a)
        		echo -e "\nDémontage annulé" && sleep 5
			break
        		;;
    		esac

	done

else 	echo -e "\n\nLe chemin vers colonial1 n'existe pas.\nDémontage annulé" && sleep 5

fi