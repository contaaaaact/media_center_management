#!/bin/bash
#suppression de fichiers en ssh surles disques externes de osmc depuis un montage samba


echo "Vous souhaitez supprimer le fichier :"
echo -e "\n$1"

NomFichier=`basename "$1"`

case "$1" in
	*/osmc/pegasus/*)
			echo -e "\nLe fichier '$NomFichier' est sur le disque :"
			echo "pegasus"
			echo -e "\nATTENTION !"
			echo " "
			ssh osmc@192.168.0.21 "find /media/pegasus/ -type f -name '"$NomFichier"' -exec rm -riv '{}' \;"
			;;

	*/osmc/pegasus4k/*)
			echo -e "\nLe fichier '$NomFichier' est sur le disque :"
			echo "pegasus4k"
			echo -e "\nATTENTION !"
			echo " "
			ssh osmc@192.168.0.21 "find /media/pegasus4k/ -type f -name '"$NomFichier"' -exec rm -riv '{}' \;"
			;;

	*/osmc/colonial1/*)
			echo -e "\nLe fichier '$NomFichier' est sur le disque :"
			echo "colonial1"
			echo -e "\nATTENTION !"
			echo " "
			ssh osmc@192.168.0.21 "find /media/colonial1/ -type f -name '"$NomFichier"' -exec rm -riv '{}' \;"
			;;
			
	*)
			echo -e "\nLe fichier '$NomFichier' n'est pas sur un disque OSMC."
			echo -e "Suppression annulée."
			;;
esac



sleep 5

exit 0

