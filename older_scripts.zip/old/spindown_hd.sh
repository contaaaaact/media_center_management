#!/bin/bash
# spindown des disques branchés

echo -e "Quel disque souhaitez vous mettre en standby ?"

# liste de choix disponibles
LISTE_spindown=("[d] demetrius" "[g] galacti4k" "[a] annuler l'opération") 
 
select i in "${LISTE_spindown[@]}" ; do
	case $REPLY in

        	1|d)
		if [ -d "/media/pi/demetrius/" ];then
			echo -e "\n\nLe chemin vers demetrius existe bien." && sudo hdparm -y /dev/disk//by-uuid/4CBC8977BC895C78 && echo -e "\ndemetrius est maintenant en standby." && sleep 5

		else echo -e "\nLe chemin vers demetrius n'existe pas, vérifiez que ce disque est branché."

		fi		

		break
		;;

       		2|g)
		if [ -d "/media/pi/galacti4k/" ];then
			echo -e "\n\nLe chemin vers galacti4k existe bien." && sudo hdparm -y /dev/disk//by-uuid/F8464C4E464C0FB4 && echo -e "\ngalacti4k est maintenant en standby." && sleep 5

		else echo -e "\nLe chemin vers galacti4k n'existe pas, vérifiez que ce disque est branché."

		fi

		break
		;;

		3|a)
       		echo -e "\nSpindown annulé" && sleep 5
		break
       		;;
  	esac

done

# fin du script