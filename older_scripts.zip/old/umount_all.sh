#!/bin/bash
# demander les comportements à suivre concernant tous les montages distants

# liste de variable disponibles
LISTEHDD=("/media/pegasus/" "/media/colonial1/" "/media/pegasus4k/") 

if ssh osmc@192.168.0.21 [ -d "${LISTEHDD}" ];then
	ssh osmc@192.168.0.21 ls -l "${LISTEHDD[@]}" && sleep 1
	echo -e "\n\nLes chemins vers les disques distants existent bien." && echo -e "Que souhaitez vous faire ?";

	# liste de choix disponibles
	LISTE=("[d] démonter tous les volumes sur osmc" "[m] monter tous les volumes en samba via /mnt/osmc/" "[a] annuler l'opération") 
 
	select i in "${LISTE[@]}" ; do
		case $REPLY in

        		1|d)
			echo -e "\nDémontage des connexions samba locales /mnt/osmc/ initialisée" && sleep 5 && sudo umount -t -cifs /mnt/osmc/pegasus && sudo umount -t -cifs /mnt/osmc/colonial1 && sudo umount -t -cifs /mnt/osmc/pegasus4k && sudo umount -t -cifs /mnt/osmc/galacti4k1 && echo -e "\nConnexions samba locale démontées." && ssh osmc@192.168.0.21 umount /media/pegasus && ssh osmc@192.168.0.21 umount /media/colonial1 && ssh osmc@192.168.0.21 umount /media/pegasus4k && echo -e "\nDémontages distants effectués" && sleep 5
			break
        		;;

        		2|m)
        		sudo mount -av && sleep 10
			break
        		;;

			3|a)
        		echo -e "\nDémontages annulés" && sleep 5
			break
        		;;
    		esac

	done

else 	echo -e "\n\nLe chemin vers les disques distants n'existe pas.\nDémontages annulés" && sleep 5

fi
