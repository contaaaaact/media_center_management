#!/bin/bash
#rsync des films 4k de galacti4k vers pegasus4k

#verification de la presence de /mnt/osmc/pegasus4k/films_4k/ puis rsync x2 entre galacti4k et pegasus4k

if [ -d "/mnt/osmc/pegasus4k/films_4k/" ];then
	echo -e "Le chemin vers les films 4k de pegasus4k existe, bond PRL initialisé !" && rsync -rtv --progress /media/pi/galacti4k/films_4k/ /mnt/osmc/pegasus4k/films_4k/ && rsync -rtv --progress /media/pi/galacti4k/films_4k/ /mnt/osmc/pegasus4k/films_4k/ && echo -e "\n\nBond PRL effectué avec succès !" && sleep 1;

else 	echo -e "Le chemin vers les films 4k de pegasus4k n'existe pas, bond PRL annulé." && sleep 1d

fi


#Demander la mise à jour de la médiathèque osmc

echo -e "\n\nVoulez vous mettre a jour la médiathèque osmc ? (yes/no)"

# liste de choix disponibles
LISTE=("[y] yes" "[n] no") 
 
select i in "${LISTE[@]}" ; do
	case $REPLY in

        	1|y)
        	ssh osmc@192.168.0.21 'xbmc-send --action="UpdateLibrary(video)"' && echo -e "\nMise a jour médiathèque effectuée" && sleep 1
        	break
		;;

        	2|n)
        	echo -e "\nMise à jour médiathèque annulée" && sleep 1
		break
        	;;
    	esac

done


#demander la suppression des fichiers sur demetrius

echo -e "\n\nVoulez vous supprimer la source de Demetrius ?"
find /media/pi/galacti4k/download_center/_to/ -type f -exec rm -riv {} \; && echo -e "\nSans notification contraire, aucun fichier n'a été supprimé du dossier _to." && sleep 5

#fin du script
