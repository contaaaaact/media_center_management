#!/bin/bash
#rsync des séries tv de demetrius vers pegasus

#verification de la presence de /mnt/osmc/pegasus/series_tv puis rsync x2 entre demetrius et pegasus

if [ -d "/mnt/osmc/pegasus/series_tv" ];then
	echo -e "Le chemin vers les séries tv de pegasus existe, bond PRL initialisé !" && rsync -rtv --progress /media/pi/demetrius/download_center/series_tv/ /mnt/osmc/pegasus/series_tv/ && rsync -rtv --progress /media/pi/demetrius/download_center/series_tv/ /mnt/osmc/pegasus/series_tv/ && echo -e "\n\nBond PRL effectué avec succès !";

else 	echo -e "Le chemin vers les séries tv de pegasus n'existe pas, bond PRL annulé." && sleep 1d

fi


#Demander la mise à jour de la médiathèque osmc

echo -e "\n\nVoulez vous mettre a jour la médiathèque osmc ? (yes/no)"

# liste de choix disponibles
LISTE=("[y] yes" "[n] no") 
 
select i in "${LISTE[@]}" ; do
	case $REPLY in

        	1|y)
        	ssh osmc@192.168.0.21 'xbmc-send --action="UpdateLibrary(video)"' && echo -e "\nMise a jour médiathèque effectuée" && sleep 1
        	break
		;;

        	2|n)
        	echo -e "\nMise à jour médiathèque annulée" && sleep 1
		break
        	;;
    	esac

done


#demander un backup sur galactica
echo -e "\n\nVoulez vous lancer une copie sur galactica ? (yes/no)"

# liste de choix disponibles
LISTE=("[y] yes" "[n] no") 
 
select i in "${LISTE[@]}" ; do
	case $REPLY in

        	1|y)
        	if [ -d "/media/pi/galactica/series_tv" ];then
			echo -e "\nLe chemin vers galactica existe, copie initialisée !" && rsync -rtv --progress /media/pi/demetrius/download_center/series_tv/ /media/pi/galactica/series_tv/ && rsync -rtv --progress -e ssh /media/pi/demetrius/download_center/series_tv/ /media/pi/galactica/series_tv/ && echo -e "\n\nCopie terminée avec succès" && sleep 1;
			break
		else	echo -e "\nLe chemin vers galactica n'existe pas, copie annulée.\nVérifiez que galactica est bien branché."
			continue
	
		fi
        	break
        	;;

        	2|n)
        	echo -e "\nCopie annulée" && sleep 1
		break
        	;;
    	esac

done


# demander de démonter galactica

if [ -d "/media/pi/galactica/" ];then
	echo -e "\n\nLe chemin vers galactica existe toujours" && echo -e "Voulez vous démonter galactica ? (yes/no)";

	# liste de choix disponibles
	LISTE=("[y] yes" "[n] no") 
 
	select i in "${LISTE[@]}" ; do
		case $REPLY in

        		1|y)
			echo -e "\nDémontage initialisé" && sleep 1 && umount /media/pi/galactica/ && echo -e "\nDémontage effectué" && sleep 1
			break
        		;;

        		2|n)
        		echo -e "\nDémontage annulé" && sleep 1
			break
        		;;
    		esac

	done

else 	echo -e "\n\nDémontage annulé" && sleep 1

fi


#demander la suppression des fichiers sur demetrius

echo -e "\n\nVoulez vous supprimer la source de Demetrius ?"
find /media/pi/demetrius/download_center/series_tv/ -type f -exec rm -riv {} \; && echo -e "\nSans notification contraire, aucun fichier n'a été supprimé du dossier series_tv." && sleep 1 && find /media/pi/demetrius/download_center/_to/ -type f -exec rm -riv {} \; && echo -e "\nSans notification contraire, aucun fichier n'a été supprimé du dossier _to." && sleep 5

#fin du script