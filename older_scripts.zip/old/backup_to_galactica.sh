#!/bin/bash
#rsync des films de pegasus et de colonial1 vers galactica

#demander la suppression les backups anterieurs des settings vero

echo -e "\n\nVoulez vous supprimer les backups anterieurs des settings vero ?"
find /media/pi/galactica/technique/backup_settings_vero -type f -exec rm -riv {} \; && echo -e "\nSans notification contraire, aucun fichier n'a été supprimé." && sleep 1


#verification de la presence de /media/galactica/

if [ -d "/media/pi/galactica/" ];then
	echo -e "Le chemin vers galactica existe, backup PRL initialisé !" && rsync -rtv --progress /mnt/osmc/pegasus/ /media/pi/galactica/ && rsync -rtv --progress /mnt/osmc/pegasus/ /media/pi/galactica/ && rsync -rtv --progress /mnt/osmc/colonial1/ /media/pi/galactica/ && rsync -rtv --progress /mnt/osmc/colonial1/ /media/pi/galactica/ && echo -e "\n\nBackup PRL effectué avec succès !";

else 	echo -e "Le chemin vers galactica n'existe pas, backup PRL annulé.\nVérifiez que galactica est bien sous tension." 

fi


# demander de démonter galactica

if [ -d "/media/pi/galactica/" ];then
	echo -e "\n\nLe chemin vers galactica existe toujours" && echo -e "Voulez vous démonter galactica ? (yes/no)";

	# liste de choix disponibles
	LISTE=("[y] yes" "[n] no") 
 
	select i in "${LISTE[@]}" ; do
		case $REPLY in

        		1|y)
			echo -e "\nDémontage initialisé" && sleep 1 && umount /media/pi/galactica && echo -e "\nDémontage effectué" && sleep 5
			break
        		;;

        		2|n)
        		echo -e "\nDémontage annulé" && sleep 5
			break
        		;;
    		esac

	done

else 	echo -e "\n\nDémontage annulé" && sleep 10

fi




#fin du script