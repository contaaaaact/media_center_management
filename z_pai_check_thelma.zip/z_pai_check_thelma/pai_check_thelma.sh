#!/bin/bash
# Verifier le stock et la date limite de consommation des médicaments du PAI

DateToday=`date +%Y-%m-%d`

echo -e "Nous sommes le :"
date +%Y-%m-%d

echo -e "\nVoici l'état du PAI de Thelma"

StockAnapen=`sed -n 5p /home/pi/scripts/z_pai_check_thelma/anapen`
StockCelestene=`sed -n 5p /home/pi/scripts/z_pai_check_thelma/celestene`
StockDesloratadine=`sed -n 5p /home/pi/scripts/z_pai_check_thelma/desloratadine`
StockFlixotide=`sed -n 5p /home/pi/scripts/z_pai_check_thelma/flixotide`
StockVentoline=`sed -n 5p /home/pi/scripts/z_pai_check_thelma/ventoline`

DLCAnapenEcole=`sed -n 9p /home/pi/scripts/z_pai_check_thelma/anapen`
DLCCelesteneEcole=`sed -n 9p /home/pi/scripts/z_pai_check_thelma/celestene`
DLCDesloratadineEcole=`sed -n 9p /home/pi/scripts/z_pai_check_thelma/desloratadine`
DLCFlixotideEcole=`sed -n 9p /home/pi/scripts/z_pai_check_thelma/flixotide`
DLCVentolineEcole=`sed -n 9p /home/pi/scripts/z_pai_check_thelma/ventoline`

DLCAnapenCentre=`sed -n 12p /home/pi/scripts/z_pai_check_thelma/anapen`
DLCCelesteneCentre=`sed -n 12p /home/pi/scripts/z_pai_check_thelma/celestene`
DLCDesloratadineCentre=`sed -n 12p /home/pi/scripts/z_pai_check_thelma/desloratadine`
DLCFlixotideCentre=`sed -n 12p /home/pi/scripts/z_pai_check_thelma/flixotide`
DLCVentolineCentre=`sed -n 12p /home/pi/scripts/z_pai_check_thelma/ventoline`

DLCAnapenMaison=`sed -n 15p /home/pi/scripts/z_pai_check_thelma/anapen`
DLCCelesteneMaison=`sed -n 15p /home/pi/scripts/z_pai_check_thelma/celestene`
DLCDesloratadineMaison=`sed -n 15p /home/pi/scripts/z_pai_check_thelma/desloratadine`
DLCFlixotideMaison=`sed -n 15p /home/pi/scripts/z_pai_check_thelma/flixotide`
DLCVentolineMaison=`sed -n 15p /home/pi/scripts/z_pai_check_thelma/ventoline`

# listing du stock

echo -e "\n-----------------------------------------"
echo -e " * STOCK"
echo -e "-----------------------------------------"
echo -e "Anapen  \t$StockAnapen"
echo -e "Celestene \t$StockCelestene"
echo -e "Desloratadine \t$StockDesloratadine"
echo -e "Flixotide \t$StockFlixotide"
echo -e "Ventoline \t$StockVentoline"

# listing DLC

echo -e "\n-----------------------------------------"
echo -e " * DATE LIMITE DE CONSOMMATION"
echo -e "-----------------------------------------"
echo -e "              \tEcole         \tCentre  \tMaison"
echo -e "Anapen  \t$DLCAnapenEcole\t$DLCAnapenCentre\t$DLCAnapenMaison"
echo -e "Celestene \t$DLCCelesteneEcole\t$DLCCelesteneCentre\t$DLCCelesteneMaison"
echo -e "Desloratadine \t$DLCDesloratadineEcole\t$DLCDesloratadineCentre\t$DLCDesloratadineMaison"
echo -e "Flixotide \t$DLCFlixotideEcole\t$DLCFlixotideCentre\t$DLCFlixotideMaison"
echo -e "Ventoline \t$DLCVentolineEcole\t$DLCVentolineCentre\t$DLCVentolineMaison"

# pointage des defauts stock

if [ $StockAnapen -lt 1 -o $StockCelestene -lt 1 -o $StockDesloratadine -lt 1 -o $StockFlixotide -lt 1 -o $StockVentoline -lt 1 ]
	then
		echo -e "\n#######################################################################"
		echo -e "   ATTENTION ! Il n'y a plus de stock pour les medicaments suivants:"
		echo -e "------------------------------------------------------------------------"
		
		
		if [ $StockAnapen -lt 1 ]
			then
				echo -e "* Anapen"
		fi  

		if [ $StockCelestene -lt 1 ]
			then
				echo -e "* Celestene"
		fi

		if [ $StockDesloratadine -lt 1 ]
			then
				echo -e "* Desloratadine"
		fi

		if [ $StockFlixotide -lt 1 ]
			then
				echo -e "* Flixotide"
		fi

		if [ $StockVentoline -lt 1 ]
			then
				echo -e "* Ventoline"
		fi
		
		#echo -e "#######################################################################"
		#echo -e "\nVeuillez prendre RDV avec le Docteur Delaet." && echo -e "Telephone Secretariat : 01 39 12 21 31" && echo -e "https://www.doctolib.fr/medecin-generaliste/maisons-laffitte/caroline-delaet"
        
	else
		echo -e "\n#######################################################################"
		echo -e "Le stock de médicament est suffisant pour continuer le traitement."
		
fi


# pointage des defauts DLC

QtiteAnapenEcole=0
QtiteAnapenCentre=0
QtiteAnapenMaison=0
QtiteCelesteneEcole=0
QtiteCelesteneCentre=0
QtiteCelesteneMaison=0
QtiteDesloratadineEcole=0
QtiteDesloratadineCentre=0
QtiteDesloratadineMaison=0
QtiteFlixotideEcole=0
QtiteFlixotideCentre=0
QtiteFlixotideMaison=0
QtiteVentolineEcole=0
QtiteVentolineCentre=0
QtiteVentolineMaison=0

if [[ $DateToday > $DLCAnapenEcole ]] || [[ $DateToday > $DLCAnapenCentre ]] || [[ $DateToday > $DLCAnapenMaison ]] || [[ $DateToday > $DLCCelesteneEcole ]] || [[ $DateToday > $DLCCelesteneCentre ]] || [[ $DateToday > $DLCCelesteneMaison ]] || [[ $DateToday > $DLCDesloratadineEcole ]] || [[ $DateToday > $DLCDesloratadineCentre ]] || [[ $DateToday > $DLCDesloratadineMaison ]] || [[ $DateToday > $DLCFlixotideEcole ]] || [[ $DateToday > $DLCFlixotideCentre ]] || [[ $DateToday > $DLCFlixotideMaison ]] || [[ $DateToday > $DLCVentolineEcole ]] || [[ $DateToday > $DLCVentolineCentre ]] || [[ $DateToday > $DLCVentolineMaison ]]
	then
		echo -e "\n#######################################################################"
		echo -e "   ATTENTION ! Les médicaments suivants sont périmés:"
		echo -e "------------------------------------------------------------------------"

		if [[ $DateToday > $DLCAnapenEcole ]]
			then
				 echo -e "* Anapen Ecole"
				 QtiteAnapenEcole=1
		fi

		if [[ $DateToday > $DLCAnapenCentre ]]
			then
				 echo -e "* Anapen Centre"
				 QtiteAnapenCentre=1
		fi
				 
		if [[ $DateToday > $DLCAnapenMaison ]]
			then
				 echo -e "* Anapen Maison"
				 QtiteAnapenMaison=1
		fi
		
		if [[ $DateToday > $DLCCelesteneEcole ]]
			then
				 echo -e "* Celestene Ecole"
				 QtiteCelesteneEcole=1
		fi

		if [[ $DateToday > $DLCCelesteneCentre ]]
			then
				 echo -e "* Celestene Centre"
				 QtiteCelesteneCentre=1
		fi
				 
		if [[ $DateToday > $DLCCelesteneMaison ]]
			then
				 echo -e "* Celestene Maison"
				 QtiteCelesteneMaison=1
		fi
		
		if [[ $DateToday > $DLCDesloratadineEcole ]]
			then
				 echo -e "* Desloratadine Ecole"
				 QtiteDesloratadineEcole=1
		fi

		if [[ $DateToday > $DLCDesloratadineCentre ]]
			then
				 echo -e "* Desloratadine Centre"
				 QtiteDesloratadineCentre=1
		fi
				 
		if [[ $DateToday > $DLCDesloratadineMaison ]]
			then
				 echo -e "* Desloratadine Maison"
				 QtiteDesloratadineMaison=1
		fi
		
		if [[ $DateToday > $DLCFlixotideEcole ]]
			then
				 echo -e "* Flixotide Ecole"
				 QtiteFlixotideEcole=1
		fi

		if [[ $DateToday > $DLCFlixotideCentre ]]
			then
				 echo -e "* Flixotide Centre"
				 QtiteFlixotideCentre=1
		fi
				 
		if [[ $DateToday > $DLCFlixotideMaison ]]
			then
				 echo -e "* Flixotide Maison"
				 QtiteFlixotideMaison=1
		fi
		
		if [[ $DateToday > $DLCVentolineEcole ]]
			then
				 echo -e "* Ventoline Ecole"
				 QtiteVentolineEcole=1
		fi

		if [[ $DateToday > $DLCVentolineCentre ]]
			then
				 echo -e "* Ventoline Centre"
				 QtiteVentolineCentre=1
		fi
				 
		if [[ $DateToday > $DLCVentolineMaison ]]
			then
				 echo -e "* Ventoline Maison"
				 QtiteVentolineMaison=1
		fi
		
else
	echo -e "\n#######################################################################"
	echo -e "Auncun médicament n'est périmé."

fi

# pointer les DLC de moins qui seront dépassées dans moins d'1mois

DLCAnapenEcole1M=`date -d "$DLCAnapenEcole-1Month" +%Y-%m-%d`
DLCAnapenCentre1M=`date -d "$DLCAnapenCentre-1Month" +%Y-%m-%d`
DLCAnapenMaison1M=`date -d "$DLCAnapenMaison-1Month" +%Y-%m-%d`
DLCCelesteneEcole1M=`date -d "$DLCCelesteneEcole-1Month" +%Y-%m-%d`
DLCCelesteneCentre1M=`date -d "$DLCCelesteneCentre-1Month" +%Y-%m-%d`
DLCCelesteneMaison1M=`date -d "$DLCCelesteneMaison-1Month" +%Y-%m-%d`
DLCDesloratadineEcole1M=`date -d "$DLCDesloratadineEcole-1Month" +%Y-%m-%d`
DLCDesloratadineCentre1M=`date -d "$DLCDesloratadineCentre-1Month" +%Y-%m-%d`
DLCDesloratadineMaison1M=`date -d "$DLCDesloratadineMaison-1Month" +%Y-%m-%d`
DLCFlixotideEcole1M=`date -d "$DLCFlixotideEcole-1Month" +%Y-%m-%d`
DLCFlixotideCentre1M=`date -d "$DLCFlixotideCentre-1Month" +%Y-%m-%d`
DLCFlixotideMaison1M=`date -d "$DLCFlixotideMaison-1Month" +%Y-%m-%d`
DLCVentolineEcole1M=`date -d "$DLCVentolineEcole-1Month" +%Y-%m-%d`
DLCVentolineCentre1M=`date -d "$DLCVentolineCentre-1Month" +%Y-%m-%d`
DLCVentolineMaison1M=`date -d "$DLCVentolineMaison-1Month" +%Y-%m-%d`

#echo $DLCAnapenEcole1M
#echo $DLCAnapenCentre1M
#echo $DLCAnapenMaison1M
#echo $DLCCelesteneEcole1M
#echo $DLCCelesteneCentre1M
#echo $DLCCelesteneMaison1M
#echo $DLCDesloratadineEcole1M
#echo $DLCDesloratadineCentre1M
#echo $DLCDesloratadineMaison1M
#echo $DLCFlixotideEcole1M
#echo $DLCFlixotideCentre1M
#echo $DLCFlixotideMaison1M
#echo $DLCVentolineEcole1M
#echo $DLCVentolineCentre1M
#echo $DLCVentolineMaison1M

QtiteAnapenEcole1M=0
QtiteAnapenCentre1M=0
QtiteAnapenMaison1M=0
QtiteCelesteneEcole1M=0
QtiteCelesteneCentre1M=0
QtiteCelesteneMaison1M=0
QtiteDesloratadineEcole1M=0
QtiteDesloratadineCentre1M=0
QtiteDesloratadineMaison1M=0
QtiteFlixotideEcole1M=0
QtiteFlixotideCentre1M=0
QtiteFlixotideMaison1M=0
QtiteVentolineEcole1M=0
QtiteVentolineCentre1M=0
QtiteVentolineMaison1M=0


if ([[ $DLCAnapenEcole1M < $DateToday ]] && [[ $DateToday < $DLCAnapenEcole ]]) || ([[ $DLCAnapenCentre1M < $DateToday ]] && [[ $DateToday < $DLCAnapenCentre ]]) || ([[ $DLCAnapenMaison1M < $DateToday ]] && [[ $DateToday < $DLCAnapenMaison ]]) || ([[ $DLCCelesteneEcole1M < $DateToday ]] && [[ $DateToday < $DLCCelesteneEcole ]]) || ([[ $DLCCelesteneCentre1M < $DateToday ]] && [[ $DateToday < $DLCCelesteneCentre ]]) || ([[ $DLCCelesteneMaison1M < $DateToday ]] && [[ $DateToday < $DLCCelesteneMaison ]]) || ([[ $DLCDesloratadineEcole1M < $DateToday ]] && [[ $DateToday < $DLCDesloratadineEcole ]]) || ([[ $DLCDesloratadineCentre1M < $DateToday ]] && [[ $DateToday < $DLCDesloratadineCentre ]]) || ([[ $DLCDesloratadineMaison1M < $DateToday ]] && [[ $DateToday < $DLCDesloratadineMaison ]]) || ([[ $DLCFlixotideEcole1M < $DateToday ]] && [[ $DateToday < $DLCFlixotideEcole ]]) || ([[ $DLCFlixotideCentre1M < $DateToday ]] && [[ $DateToday < $DLCFlixotideCentre ]]) || ([[ $DLCFlixotideMaison1M < $DateToday ]] && [[ $DateToday < $DLCFlixotideMaison ]]) || ([[ $DLCVentolineEcole1M < $DateToday ]] && [[ $DateToday < $DLCVentolineEcole ]]) || ([[ $DLCVentolineCentre1M < $DateToday ]] && [[ $DateToday < $DLCVentolineCentre ]]) || ([[ $DLCVentolineMaison1M < $DateToday ]] && [[ $DateToday < $DLCVentolineMaison ]])
	then
		echo -e "\n#######################################################################"
		echo -e "   ATTENTION ! Les médicaments suivants périment dans 1 mois:"
		echo -e "------------------------------------------------------------------------"
	
	
		if [[ $DLCAnapenEcole1M < $DateToday ]] && [[ $DateToday < $DLCAnapenEcole ]]	
				then
					 echo -e "* Anapen Ecole\t$DLCAnapenEcole"
					 QtiteAnapenEcole1M=1
		fi

		if [[ $DLCAnapenCentre1M < $DateToday ]] && [[ $DateToday < $DLCAnapenCentre ]]	
				then
					 echo -e "* Anapen Centre\t$DLCAnapenCentre"
					 QtiteAnapenCentre1M=1
		fi

		if [[ $DLCAnapenMaison1M < $DateToday ]] && [[ $DateToday < $DLCAnapenMaison ]]	
				then
					 echo -e "* Anapen Maison\t$DLCAnapenMaison"
					 QtiteAnapenMaison1M=1
		fi

		if [[ $DLCCelesteneEcole1M < $DateToday ]] && [[ $DateToday < $DLCCelesteneEcole ]]	
				then
					 echo -e "* Celestene Ecole\t$DLCCelesteneEcole"
					 QtiteCelesteneEcole1M=1
		fi

		if [[ $DLCCelesteneCentre1M < $DateToday ]] && [[ $DateToday < $DLCCelesteneCentre ]]	
				then
					 echo -e "* Celestene Centre\t$DLCCelesteneCentre"
					 QtiteCelesteneCentre1M=1
		fi

		if [[ $DLCCelesteneMaison1M < $DateToday ]] && [[ $DateToday < $DLCCelesteneMaison ]]	
				then
					 echo -e "* Celestene Maison\t$DLCCelesteneMaison"
					 QtiteCelesteneMaison1M=1
		fi

		if [[ $DLCDesloratadineEcole1M < $DateToday ]] && [[ $DateToday < $DLCDesloratadineEcole ]]	
				then
					 echo -e "* Desloratadine Ecole\t$DLCDesloratadineEcole"
					 QtiteDesloratadineEcole1M=1
		fi

		if [[ $DLCDesloratadineCentre1M < $DateToday ]] && [[ $DateToday < $DLCDesloratadineCentre ]]	
				then
					 echo -e "* Desloratadine Centre\t$DLCDesloratadineCentre"
					 QtiteDesloratadineCentre1M=1
		fi

		if [[ $DLCDesloratadineMaison1M < $DateToday ]] && [[ $DateToday < $DLCDesloratadineMaison ]]	
				then
					 echo -e "* Desloratadine Maison\t$DLCDesloratadineMaison"
					 QtiteDesloratadineMaison1M=1
		fi

		if [[ $DLCFlixotideEcole1M < $DateToday ]] && [[ $DateToday < $DLCFlixotideEcole ]]	
				then
					 echo -e "* Flixotide Ecole\t$DLCFlixotideEcole"
					 QtiteFlixotideEcole1M=1
		fi

		if [[ $DLCFlixotideCentre1M < $DateToday ]] && [[ $DateToday < $DLCFlixotideCentre ]]	
				then
					 echo -e "* Flixotide Centre\t$DLCFlixotideCentre"
					 QtiteFlixotideCentre1M=1
		fi

		if [[ $DLCFlixotideMaison1M < $DateToday ]] && [[ $DateToday < $DLCFlixotideMaison ]]	
				then
					 echo -e "* Flixotide Maison\t$DLCFlixotideMaison"
					 QtiteFlixotideMaison1M=1
		fi

		if [[ $DLCVentolineEcole1M < $DateToday ]] && [[ $DateToday < $DLCVentolineEcole ]]	
				then
					 echo -e "* Ventoline Ecole\t$DLCVentolineEcole"
					 QtiteVentolineEcole1M=1
		fi

		if [[ $DLCVentolineCentre1M < $DateToday ]] && [[ $DateToday < $DLCVentolineCentre ]]	
				then
					 echo -e "* Ventoline Centre\t$DLCVentolineCentre"
					 QtiteVentolineCentre1M=1
		fi

		if [[ $DLCVentolineMaison1M < $DateToday ]] && [[ $DateToday < $DLCVentolineMaison ]]	
				then
					 echo -e "* Ventoline Maison\t$DLCVentolineMaison"
					 QtiteVentolineMaison1M=1
		fi

else
	echo -e "\n#######################################################################"
	echo -e "Auncun médicament ne périme dans moins d'un mois."
	
fi

# Ordonance

QtiteAnapenTotal=$(($QtiteAnapenEcole+$QtiteAnapenCentre+$QtiteAnapenMaison))
QtiteCelesteneTotal=$(($QtiteCelesteneEcole+$QtiteCelesteneCentre+$QtiteCelesteneMaison))
QtiteDesloratadineTotal=$(($QtiteDesloratadineEcole+$QtiteDesloratadineCentre+$QtiteDesloratadineMaison))
QtiteFlixotideTotal=$(($QtiteFlixotideEcole+$QtiteFlixotideCentre+$QtiteFlixotideMaison))
QtiteVentolineTotal=$(($QtiteVentolineEcole+$QtiteVentolineCentre+$QtiteVentolineMaison))

QtiteAnapenTotal1M=$(($QtiteAnapenEcole1M+$QtiteAnapenCentre1M+$QtiteAnapenMaison1M))
QtiteCelesteneTotal1M=$(($QtiteCelesteneEcole1M+$QtiteCelesteneCentre1M+$QtiteCelesteneMaison1M))
QtiteDesloratadineTotal1M=$(($QtiteDesloratadineEcole1M+$QtiteDesloratadineCentre1M+$QtiteDesloratadineMaison1M))
QtiteFlixotideTotal1M=$(($QtiteFlixotideEcole1M+$QtiteFlixotideCentre1M+$QtiteFlixotideMaison1M))
QtiteVentolineTotal1M=$(($QtiteVentolineEcole1M+$QtiteVentolineCentre1M+$QtiteVentolineMaison1M))

AddStockAnapen=0
AddStockCelestene=0
AddStockDesloratadine=0
AddStockFlixotide=0
AddStockVentoline=0

if [ $StockAnapen -le 1 ]
	then AddStockAnapen=1
fi

if [ $StockCelestene -le 1 ]
	then AddStockCelestene=1
fi

if [ $StockDesloratadine -le 1 ]
	then AddStockDesloratadine=1
fi

if [ $StockFlixotide -le 1 ]
	then AddStockFlixotide=1
fi

if [ $StockVentoline -le 1 ]
	then AddStockVentoline=1
fi

QtiteAnapenDef=$(($QtiteAnapenTotal+$QtiteAnapenTotal1M-$StockAnapen+$AddStockAnapen))

if [ $QtiteAnapenDef -le 0 ]
	then QtiteAnapenDef=0
fi

QtiteCelesteneDef=$(($QtiteCelesteneTotal+$QtiteCelesteneTotal1M-$StockCelestene+$AddStockCelestene))

if [ $QtiteCelesteneDef -le 0 ]
	then QtiteCelesteneDef=0
fi

QtiteDesloratadineDef=$(($QtiteDesloratadineTotal+$QtiteDesloratadineTotal1M-$StockDesloratadine+$AddStockDesloratadine))

if [ $QtiteDesloratadineDef -le 0 ]
	then QtiteDesloratadineDef=0
fi

QtiteFlixotideDef=$(($QtiteFlixotideTotal+$QtiteFlixotideTotal1M-$StockFlixotide+$AddStockFlixotide))

if [ $QtiteFlixotideDef -le 0 ]
	then QtiteFlixotideDef=0
fi

QtiteVentolineDef=$(($QtiteVentolineTotal+$QtiteVentolineTotal1M-$StockVentoline+$AddStockVentoline))

if [ $QtiteVentolineDef -le 0 ]
	then QtiteVentolineDef=0
fi


echo -e "\n#######################################################################"
echo -e "Ordonance à faire:"
echo -e "------------------------------------------------------------------------"
echo -e "* $QtiteAnapenDef Anapen      \t(dont 	$QtiteAnapenTotal1M DLC < 1 mois 	et $AddStockAnapen stock)"
echo -e "* $QtiteCelesteneDef Celestene     \t(dont 	$QtiteCelesteneTotal1M DLC < 1 mois 	et $AddStockCelestene stock)"
echo -e "* $QtiteDesloratadineDef Desloratadine \t(dont 	$QtiteDesloratadineTotal1M DLC < 1 mois 	et $AddStockDesloratadine stock)"
echo -e "* $QtiteFlixotideDef Flixotide     \t(dont 	$QtiteFlixotideTotal1M DLC < 1 mois 	et $AddStockFlixotide stock)"
echo -e "* $QtiteVentolineDef Ventoline     \t(dont 	$QtiteVentolineTotal1M DLC < 1 mois 	et $AddStockVentoline stock)"


echo -e "\n#######################################################################"
echo -e "Veuillez prendre RDV avec le Docteur Delaet." && echo -e "Telephone Secretariat : 01 39 12 21 31" && echo -e "https://www.doctolib.fr/medecin-generaliste/maisons-laffitte/caroline-delaet"


sleep 6d
