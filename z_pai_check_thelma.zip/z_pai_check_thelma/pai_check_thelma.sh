#!/bin/bash
# Verifier le stock et la date limite de consommation des médicaments du PAI

DateToday=`date +%Y-%m-%d`

echo -e "Nous sommes le :"
date +%Y-%m-%d

echo -e "\nVoici l'état du PAI de Thelma"

StockAnapen=`sed -n 5p /home/pi/scripts/z_pai_check_thelma/anapen`
StockSolupred=`sed -n 5p /home/pi/scripts/z_pai_check_thelma/solupred`
StockDesloratadine=`sed -n 5p /home/pi/scripts/z_pai_check_thelma/desloratadine`
StockFlixotide=`sed -n 5p /home/pi/scripts/z_pai_check_thelma/flixotide`
StockVentoline=`sed -n 5p /home/pi/scripts/z_pai_check_thelma/ventoline`

DLCAnapenEcole=`sed -n 9p /home/pi/scripts/z_pai_check_thelma/anapen`
DLCSolupredEcole=`sed -n 9p /home/pi/scripts/z_pai_check_thelma/solupred`
DLCDesloratadineEcole=`sed -n 9p /home/pi/scripts/z_pai_check_thelma/desloratadine`
DLCFlixotideEcole=`sed -n 9p /home/pi/scripts/z_pai_check_thelma/flixotide`
DLCVentolineEcole=`sed -n 9p /home/pi/scripts/z_pai_check_thelma/ventoline`

DLCAnapenCentre=`sed -n 12p /home/pi/scripts/z_pai_check_thelma/anapen`
DLCSolupredCentre=`sed -n 12p /home/pi/scripts/z_pai_check_thelma/solupred`
DLCDesloratadineCentre=`sed -n 12p /home/pi/scripts/z_pai_check_thelma/desloratadine`
DLCFlixotideCentre=`sed -n 12p /home/pi/scripts/z_pai_check_thelma/flixotide`
DLCVentolineCentre=`sed -n 12p /home/pi/scripts/z_pai_check_thelma/ventoline`

DLCAnapenMaison=`sed -n 15p /home/pi/scripts/z_pai_check_thelma/anapen`
DLCSolupredMaison=`sed -n 15p /home/pi/scripts/z_pai_check_thelma/solupred`
DLCDesloratadineMaison=`sed -n 15p /home/pi/scripts/z_pai_check_thelma/desloratadine`
DLCFlixotideMaison=`sed -n 15p /home/pi/scripts/z_pai_check_thelma/flixotide`
DLCVentolineMaison=`sed -n 15p /home/pi/scripts/z_pai_check_thelma/ventoline`

DLCAnapenFevret=`sed -n 18p /home/pi/scripts/z_pai_check_thelma/anapen`
DLCSolupredFevret=`sed -n 18p /home/pi/scripts/z_pai_check_thelma/solupred`
DLCDesloratadineFevret=`sed -n 18p /home/pi/scripts/z_pai_check_thelma/desloratadine`
DLCFlixotideFevret=`sed -n 18p /home/pi/scripts/z_pai_check_thelma/flixotide`
DLCVentolineFevret=`sed -n 18p /home/pi/scripts/z_pai_check_thelma/ventoline`

# listing du stock

echo -e "\n-----------------------------------------"
echo -e " * STOCK"
echo -e "-----------------------------------------"
echo -e "Anapen  \t$StockAnapen"
echo -e "Solupred \t$StockSolupred"
echo -e "Desloratadine \t$StockDesloratadine"
echo -e "Flixotide \t$StockFlixotide"
echo -e "Ventoline \t$StockVentoline"

# listing DLC

echo -e "\n-----------------------------------------"
echo -e " * DATE LIMITE DE CONSOMMATION"
echo -e "-----------------------------------------"
echo -e "              \tEcole         \tCentre  \tMaison	\tFevret"
echo -e "Anapen  \t$DLCAnapenEcole\t$DLCAnapenCentre\t$DLCAnapenMaison\t$DLCAnapenFevret"
echo -e "Solupred \t$DLCSolupredEcole\t$DLCSolupredCentre\t$DLCSolupredMaison\t$DLCSolupredFevret"
echo -e "Desloratadine \t$DLCDesloratadineEcole\t$DLCDesloratadineCentre\t$DLCDesloratadineMaison\t$DLCDesloratadineFevret"
echo -e "Flixotide \t$DLCFlixotideEcole\t$DLCFlixotideCentre\t$DLCFlixotideMaison\t$DLCFlixotideFevret"
echo -e "Ventoline \t$DLCVentolineEcole\t$DLCVentolineCentre\t$DLCVentolineMaison\t$DLCVentolineFevret"

# pointage des defauts stock

if [ $StockAnapen -lt 1 -o $StockSolupred -lt 1 -o $StockDesloratadine -lt 1 -o $StockFlixotide -lt 1 -o $StockVentoline -lt 1 ]
	then
		echo -e "\n#######################################################################"
		echo -e "   ATTENTION ! Il n'y a plus de stock pour les medicaments suivants:"
		echo -e "------------------------------------------------------------------------"
		
		
		if [ $StockAnapen -lt 1 ]
			then
				echo -e "* Anapen"
		fi  

		if [ $StockSolupred -lt 1 ]
			then
				echo -e "* Solupred"
		fi

		if [ $StockDesloratadine -lt 1 ]
			then
				echo -e "* Desloratadine"
		fi

		if [ $StockFlixotide -lt 1 ]
			then
				echo -e "* Flixotide"
		fi

		if [ $StockVentoline -lt 1 ]
			then
				echo -e "* Ventoline"
		fi
		
		#echo -e "#######################################################################"
		#echo -e "\nVeuillez prendre RDV avec le Docteur Delaet." && echo -e "Telephone Secretariat : 01 39 12 21 31" && echo -e "https://www.doctolib.fr/medecin-generaliste/maisons-laffitte/caroline-delaet"
        
	else
		echo -e "\n#######################################################################"
		echo -e "Le stock de médicament est suffisant pour continuer le traitement."
		
fi


# pointage des defauts DLC

QtiteAnapenEcole=0
QtiteAnapenCentre=0
QtiteAnapenMaison=0
QtiteAnapenFevret=0
QtiteSolupredEcole=0
QtiteSolupredCentre=0
QtiteSolupredMaison=0
QtiteSolupredFevret=0
QtiteDesloratadineEcole=0
QtiteDesloratadineCentre=0
QtiteDesloratadineMaison=0
QtiteDesloratadineFevret=0
QtiteFlixotideEcole=0
QtiteFlixotideCentre=0
QtiteFlixotideMaison=0
QtiteFlixotideFevret=0
QtiteVentolineEcole=0
QtiteVentolineCentre=0
QtiteVentolineMaison=0
QtiteVentolineFevret=0

if [[ $DateToday > $DLCAnapenEcole ]] || [[ $DateToday > $DLCAnapenCentre ]] || [[ $DateToday > $DLCAnapenMaison ]] || [[ $DateToday > $DLCAnapenFevret ]] || [[ $DateToday > $DLCSolupredEcole ]] || [[ $DateToday > $DLCSolupredCentre ]] || [[ $DateToday > $DLCSolupredMaison ]] || [[ $DateToday > $DLCSolupredFevret ]] || [[ $DateToday > $DLCDesloratadineEcole ]] || [[ $DateToday > $DLCDesloratadineCentre ]] || [[ $DateToday > $DLCDesloratadineMaison ]] || [[ $DateToday > $DLCDesloratadineFevret ]] || [[ $DateToday > $DLCFlixotideEcole ]] || [[ $DateToday > $DLCFlixotideCentre ]] || [[ $DateToday > $DLCFlixotideMaison ]] || [[ $DateToday > $DLCFlixotideFevret ]] || [[ $DateToday > $DLCVentolineEcole ]] || [[ $DateToday > $DLCVentolineCentre ]] || [[ $DateToday > $DLCVentolineMaison ]] || [[ $DateToday > $DLCVentolineFevret ]]
	then
		echo -e "\n#######################################################################"
		echo -e "   ATTENTION ! Les médicaments suivants sont périmés:"
		echo -e "------------------------------------------------------------------------"

		if [[ $DateToday > $DLCAnapenEcole ]]
			then
				 echo -e "* Anapen Ecole"
				 QtiteAnapenEcole=1
		fi

		if [[ $DateToday > $DLCAnapenCentre ]]
			then
				 echo -e "* Anapen Centre"
				 QtiteAnapenCentre=1
		fi
				 
		if [[ $DateToday > $DLCAnapenMaison ]]
			then
				 echo -e "* Anapen Maison"
				 QtiteAnapenMaison=1
		fi

		if [[ $DateToday > $DLCAnapenFevret ]]
			then
				 echo -e "* Anapen Fevret"
				 QtiteAnapenFevret=1
		fi
		
		if [[ $DateToday > $DLCSolupredEcole ]]
			then
				 echo -e "* Solupred Ecole"
				 QtiteSolupredEcole=1
		fi

		if [[ $DateToday > $DLCSolupredCentre ]]
			then
				 echo -e "* Solupred Centre"
				 QtiteSolupredCentre=1
		fi
				 
		if [[ $DateToday > $DLCSolupredMaison ]]
			then
				 echo -e "* Solupred Maison"
				 QtiteSolupredMaison=1
		fi
		
		if [[ $DateToday > $DLCSolupredFevret ]]
			then
				 echo -e "* Solupred Fevret"
				 QtiteSolupredFevret=1
		fi
				
		if [[ $DateToday > $DLCDesloratadineEcole ]]
			then
				 echo -e "* Desloratadine Ecole"
				 QtiteDesloratadineEcole=1
		fi

		if [[ $DateToday > $DLCDesloratadineCentre ]]
			then
				 echo -e "* Desloratadine Centre"
				 QtiteDesloratadineCentre=1
		fi
				 
		if [[ $DateToday > $DLCDesloratadineMaison ]]
			then
				 echo -e "* Desloratadine Maison"
				 QtiteDesloratadineMaison=1
		fi
		
		if [[ $DateToday > $DLCDesloratadineFevret ]]
			then
				 echo -e "* Desloratadine Fevret"
				 QtiteDesloratadineFevret=1
		fi
		
		if [[ $DateToday > $DLCFlixotideEcole ]]
			then
				 echo -e "* Flixotide Ecole"
				 QtiteFlixotideEcole=1
		fi

		if [[ $DateToday > $DLCFlixotideCentre ]]
			then
				 echo -e "* Flixotide Centre"
				 QtiteFlixotideCentre=1
		fi
				 
		if [[ $DateToday > $DLCFlixotideMaison ]]
			then
				 echo -e "* Flixotide Maison"
				 QtiteFlixotideMaison=1
		fi

		if [[ $DateToday > $DLCFlixotideFevret ]]
			then
				 echo -e "* Flixotide Fevret"
				 QtiteFlixotideFevret=1
		fi
	
		if [[ $DateToday > $DLCVentolineEcole ]]
			then
				 echo -e "* Ventoline Ecole"
				 QtiteVentolineEcole=1
		fi

		if [[ $DateToday > $DLCVentolineCentre ]]
			then
				 echo -e "* Ventoline Centre"
				 QtiteVentolineCentre=1
		fi
				 
		if [[ $DateToday > $DLCVentolineMaison ]]
			then
				 echo -e "* Ventoline Maison"
				 QtiteVentolineMaison=1
		fi
				 
		if [[ $DateToday > $DLCVentolineFevret ]]
			then
				 echo -e "* Ventoline Fevret"
				 QtiteVentolineFevret=1
		fi
			
else
	echo -e "\n#######################################################################"
	echo -e "Auncun médicament n'est périmé."

fi

# pointer les DLC de moins qui seront dépassées dans moins d'1mois

DLCAnapenEcole1M=`date -d "$DLCAnapenEcole-1Month" +%Y-%m-%d`
DLCAnapenCentre1M=`date -d "$DLCAnapenCentre-1Month" +%Y-%m-%d`
DLCAnapenMaison1M=`date -d "$DLCAnapenMaison-1Month" +%Y-%m-%d`
DLCAnapenFevret1M=`date -d "$DLCAnapenFevret-1Month" +%Y-%m-%d`
DLCSolupredEcole1M=`date -d "$DLCSolupredEcole-1Month" +%Y-%m-%d`
DLCSolupredCentre1M=`date -d "$DLCSolupredCentre-1Month" +%Y-%m-%d`
DLCSolupredMaison1M=`date -d "$DLCSolupredMaison-1Month" +%Y-%m-%d`
DLCSolupredFevret1M=`date -d "$DLCSolupredFevret-1Month" +%Y-%m-%d`
DLCDesloratadineEcole1M=`date -d "$DLCDesloratadineEcole-1Month" +%Y-%m-%d`
DLCDesloratadineCentre1M=`date -d "$DLCDesloratadineCentre-1Month" +%Y-%m-%d`
DLCDesloratadineMaison1M=`date -d "$DLCDesloratadineMaison-1Month" +%Y-%m-%d`
DLCDesloratadineFevret1M=`date -d "$DLCDesloratadineFevret-1Month" +%Y-%m-%d`
DLCFlixotideEcole1M=`date -d "$DLCFlixotideEcole-1Month" +%Y-%m-%d`
DLCFlixotideCentre1M=`date -d "$DLCFlixotideCentre-1Month" +%Y-%m-%d`
DLCFlixotideMaison1M=`date -d "$DLCFlixotideMaison-1Month" +%Y-%m-%d`
DLCFlixotideFevret1M=`date -d "$DLCFlixotideFevret-1Month" +%Y-%m-%d`
DLCVentolineEcole1M=`date -d "$DLCVentolineEcole-1Month" +%Y-%m-%d`
DLCVentolineCentre1M=`date -d "$DLCVentolineCentre-1Month" +%Y-%m-%d`
DLCVentolineMaison1M=`date -d "$DLCVentolineMaison-1Month" +%Y-%m-%d`
DLCVentolineFevret1M=`date -d "$DLCVentolineFevret-1Month" +%Y-%m-%d`

#echo $DLCAnapenEcole1M
#echo $DLCAnapenCentre1M
#echo $DLCAnapenMaison1M
#echo $DLCSolupredEcole1M
#echo $DLCSolupredCentre1M
#echo $DLCSolupredMaison1M
#echo $DLCDesloratadineEcole1M
#echo $DLCDesloratadineCentre1M
#echo $DLCDesloratadineMaison1M
#echo $DLCFlixotideEcole1M
#echo $DLCFlixotideCentre1M
#echo $DLCFlixotideMaison1M
#echo $DLCVentolineEcole1M
#echo $DLCVentolineCentre1M
#echo $DLCVentolineMaison1M

QtiteAnapenEcole1M=0
QtiteAnapenCentre1M=0
QtiteAnapenMaison1M=0
QtiteAnapenFevret1M=0
QtiteSolupredEcole1M=0
QtiteSolupredCentre1M=0
QtiteSolupredMaison1M=0
QtiteSolupredFevret1M=0
QtiteDesloratadineEcole1M=0
QtiteDesloratadineCentre1M=0
QtiteDesloratadineMaison1M=0
QtiteDesloratadineFevret1M=0
QtiteFlixotideEcole1M=0
QtiteFlixotideCentre1M=0
QtiteFlixotideMaison1M=0
QtiteFlixotideFevret1M=0
QtiteVentolineEcole1M=0
QtiteVentolineCentre1M=0
QtiteVentolineMaison1M=0
QtiteVentolineFevret1M=0


if ([[ $DLCAnapenEcole1M < $DateToday ]] && [[ $DateToday < $DLCAnapenEcole ]]) || ([[ $DLCAnapenCentre1M < $DateToday ]] && [[ $DateToday < $DLCAnapenCentre ]]) || ([[ $DLCAnapenMaison1M < $DateToday ]] && [[ $DateToday < $DLCAnapenMaison ]]) || ([[ $DLCAnapenFevret1M < $DateToday ]] && [[ $DateToday < $DLCAnapenFevret ]]) || ([[ $DLCSolupredEcole1M < $DateToday ]] && [[ $DateToday < $DLCSolupredEcole ]]) || ([[ $DLCSolupredCentre1M < $DateToday ]] && [[ $DateToday < $DLCSolupredCentre ]]) || ([[ $DLCSolupredMaison1M < $DateToday ]] && [[ $DateToday < $DLCSolupredMaison ]]) || ([[ $DLCSolupredFevret1M < $DateToday ]] && [[ $DateToday < $DLCSolupredFevret ]]) || ([[ $DLCDesloratadineEcole1M < $DateToday ]] && [[ $DateToday < $DLCDesloratadineEcole ]]) || ([[ $DLCDesloratadineCentre1M < $DateToday ]] && [[ $DateToday < $DLCDesloratadineCentre ]]) || ([[ $DLCDesloratadineMaison1M < $DateToday ]] && [[ $DateToday < $DLCDesloratadineMaison ]]) || ([[ $DLCDesloratadineFevret1M < $DateToday ]] && [[ $DateToday < $DLCDesloratadineFevret ]]) || ([[ $DLCFlixotideEcole1M < $DateToday ]] && [[ $DateToday < $DLCFlixotideEcole ]]) || ([[ $DLCFlixotideCentre1M < $DateToday ]] && [[ $DateToday < $DLCFlixotideCentre ]]) || ([[ $DLCFlixotideMaison1M < $DateToday ]] && [[ $DateToday < $DLCFlixotideMaison ]]) || ([[ $DLCFlixotideFevret1M < $DateToday ]] && [[ $DateToday < $DLCFlixotideFevret ]]) || ([[ $DLCVentolineEcole1M < $DateToday ]] && [[ $DateToday < $DLCVentolineEcole ]]) || ([[ $DLCVentolineCentre1M < $DateToday ]] && [[ $DateToday < $DLCVentolineCentre ]]) || ([[ $DLCVentolineMaison1M < $DateToday ]] && [[ $DateToday < $DLCVentolineMaison ]]) || ([[ $DLCVentolineFevret1M < $DateToday ]] && [[ $DateToday < $DLCVentolineFevret ]])
	then
		echo -e "\n#######################################################################"
		echo -e "   ATTENTION ! Les médicaments suivants périment dans 1 mois:"
		echo -e "------------------------------------------------------------------------"
	
	
		if [[ $DLCAnapenEcole1M < $DateToday ]] && [[ $DateToday < $DLCAnapenEcole ]]	
				then
					 echo -e "* Anapen Ecole\t$DLCAnapenEcole"
					 QtiteAnapenEcole1M=1
		fi

		if [[ $DLCAnapenCentre1M < $DateToday ]] && [[ $DateToday < $DLCAnapenCentre ]]	
				then
					 echo -e "* Anapen Centre\t$DLCAnapenCentre"
					 QtiteAnapenCentre1M=1
		fi

		if [[ $DLCAnapenMaison1M < $DateToday ]] && [[ $DateToday < $DLCAnapenMaison ]]	
				then
					 echo -e "* Anapen Maison\t$DLCAnapenMaison"
					 QtiteAnapenMaison1M=1
		fi
		
		if [[ $DLCAnapenFevret1M < $DateToday ]] && [[ $DateToday < $DLCAnapenFevret ]]	
				then
					 echo -e "* Anapen Fevret\t$DLCAnapenFevret"
					 QtiteAnapenFevret1M=1
		fi

		if [[ $DLCSolupredEcole1M < $DateToday ]] && [[ $DateToday < $DLCSolupredEcole ]]	
				then
					 echo -e "* Solupred Ecole\t$DLCSolupredEcole"
					 QtiteSolupredEcole1M=1
		fi

		if [[ $DLCSolupredCentre1M < $DateToday ]] && [[ $DateToday < $DLCSolupredCentre ]]	
				then
					 echo -e "* Solupred Centre\t$DLCSolupredCentre"
					 QtiteSolupredCentre1M=1
		fi

		if [[ $DLCSolupredMaison1M < $DateToday ]] && [[ $DateToday < $DLCSolupredMaison ]]	
				then
					 echo -e "* Solupred Maison\t$DLCSolupredMaison"
					 QtiteSolupredMaison1M=1
		fi
		
		if [[ $DLCSolupredFevret1M < $DateToday ]] && [[ $DateToday < $DLCSolupredFevret ]]	
				then
					 echo -e "* Solupred Fevret\t$DLCSolupredFevret"
					 QtiteSolupredFevret1M=1
		fi

		if [[ $DLCDesloratadineEcole1M < $DateToday ]] && [[ $DateToday < $DLCDesloratadineEcole ]]	
				then
					 echo -e "* Desloratadine Ecole\t$DLCDesloratadineEcole"
					 QtiteDesloratadineEcole1M=1
		fi

		if [[ $DLCDesloratadineCentre1M < $DateToday ]] && [[ $DateToday < $DLCDesloratadineCentre ]]	
				then
					 echo -e "* Desloratadine Centre\t$DLCDesloratadineCentre"
					 QtiteDesloratadineCentre1M=1
		fi

		if [[ $DLCDesloratadineMaison1M < $DateToday ]] && [[ $DateToday < $DLCDesloratadineMaison ]]	
				then
					 echo -e "* Desloratadine Maison\t$DLCDesloratadineMaison"
					 QtiteDesloratadineMaison1M=1
		fi

		if [[ $DLCDesloratadineFevret1M < $DateToday ]] && [[ $DateToday < $DLCDesloratadineFevret ]]	
				then
					 echo -e "* Desloratadine Fevret\t$DLCDesloratadineFevret"
					 QtiteDesloratadineFevret1M=1
		fi

		if [[ $DLCFlixotideEcole1M < $DateToday ]] && [[ $DateToday < $DLCFlixotideEcole ]]	
				then
					 echo -e "* Flixotide Ecole\t$DLCFlixotideEcole"
					 QtiteFlixotideEcole1M=1
		fi

		if [[ $DLCFlixotideCentre1M < $DateToday ]] && [[ $DateToday < $DLCFlixotideCentre ]]	
				then
					 echo -e "* Flixotide Centre\t$DLCFlixotideCentre"
					 QtiteFlixotideCentre1M=1
		fi

		if [[ $DLCFlixotideMaison1M < $DateToday ]] && [[ $DateToday < $DLCFlixotideMaison ]]	
				then
					 echo -e "* Flixotide Maison\t$DLCFlixotideMaison"
					 QtiteFlixotideMaison1M=1
		fi
		
		if [[ $DLCFlixotideFevret1M < $DateToday ]] && [[ $DateToday < $DLCFlixotideFevret ]]	
				then
					 echo -e "* Flixotide Fevret\t$DLCFlixotideFevret"
					 QtiteFlixotideFevret1M=1
		fi

		if [[ $DLCVentolineEcole1M < $DateToday ]] && [[ $DateToday < $DLCVentolineEcole ]]	
				then
					 echo -e "* Ventoline Ecole\t$DLCVentolineEcole"
					 QtiteVentolineEcole1M=1
		fi

		if [[ $DLCVentolineCentre1M < $DateToday ]] && [[ $DateToday < $DLCVentolineCentre ]]	
				then
					 echo -e "* Ventoline Centre\t$DLCVentolineCentre"
					 QtiteVentolineCentre1M=1
		fi

		if [[ $DLCVentolineMaison1M < $DateToday ]] && [[ $DateToday < $DLCVentolineMaison ]]	
				then
					 echo -e "* Ventoline Maison\t$DLCVentolineMaison"
					 QtiteVentolineMaison1M=1
		fi
		
		if [[ $DLCVentolineFevret1M < $DateToday ]] && [[ $DateToday < $DLCVentolineFevret ]]	
				then
					 echo -e "* Ventoline Fevret\t$DLCVentolineFevret"
					 QtiteVentolineFevret1M=1
		fi

else
	echo -e "\n#######################################################################"
	echo -e "Auncun médicament ne périme dans moins d'un mois."
	
fi

# Ordonance

QtiteAnapenTotal=$(($QtiteAnapenEcole+$QtiteAnapenCentre+$QtiteAnapenMaison+$QtiteAnapenFevret))
QtiteSolupredTotal=$(($QtiteSolupredEcole+$QtiteSolupredCentre+$QtiteSolupredMaison+$QtiteSolupredFevret))
QtiteDesloratadineTotal=$(($QtiteDesloratadineEcole+$QtiteDesloratadineCentre+$QtiteDesloratadineMaison+$QtiteDesloratadineFevret))
QtiteFlixotideTotal=$(($QtiteFlixotideEcole+$QtiteFlixotideCentre+$QtiteFlixotideMaison+$QtiteFlixotideFevret))
QtiteVentolineTotal=$(($QtiteVentolineEcole+$QtiteVentolineCentre+$QtiteVentolineMaison+$QtiteVentolineFevret))

QtiteAnapenTotal1M=$(($QtiteAnapenEcole1M+$QtiteAnapenCentre1M+$QtiteAnapenMaison1M+$QtiteAnapenFevret1M))
QtiteSolupredTotal1M=$(($QtiteSolupredEcole1M+$QtiteSolupredCentre1M+$QtiteSolupredMaison1M+$QtiteSolupredFevret1M))
QtiteDesloratadineTotal1M=$(($QtiteDesloratadineEcole1M+$QtiteDesloratadineCentre1M+$QtiteDesloratadineMaison1M+$QtiteDesloratadineFevret1M))
QtiteFlixotideTotal1M=$(($QtiteFlixotideEcole1M+$QtiteFlixotideCentre1M+$QtiteFlixotideMaison1M+$QtiteFlixotideFevret1M))
QtiteVentolineTotal1M=$(($QtiteVentolineEcole1M+$QtiteVentolineCentre1M+$QtiteVentolineMaison1M+$QtiteVentolineFevret1M))

AddStockAnapen=0
AddStockSolupred=0
AddStockDesloratadine=0
AddStockFlixotide=0
AddStockVentoline=0

if [ $StockAnapen -le 1 ]
	then AddStockAnapen=1
fi

if [ $StockSolupred -le 1 ]
	then AddStockSolupred=1
fi

if [ $StockDesloratadine -le 1 ]
	then AddStockDesloratadine=1
fi

if [ $StockFlixotide -le 1 ]
	then AddStockFlixotide=1
fi

if [ $StockVentoline -le 1 ]
	then AddStockVentoline=1
fi

QtiteAnapenDef=$(($QtiteAnapenTotal+$QtiteAnapenTotal1M-$StockAnapen+$AddStockAnapen))

if [ $QtiteAnapenDef -le 0 ]
	then QtiteAnapenDef=0
fi

QtiteSolupredDef=$(($QtiteSolupredTotal+$QtiteSolupredTotal1M-$StockSolupred+$AddStockSolupred))

if [ $QtiteSolupredDef -le 0 ]
	then QtiteSolupredDef=0
fi

QtiteDesloratadineDef=$(($QtiteDesloratadineTotal+$QtiteDesloratadineTotal1M-$StockDesloratadine+$AddStockDesloratadine))

if [ $QtiteDesloratadineDef -le 0 ]
	then QtiteDesloratadineDef=0
fi

QtiteFlixotideDef=$(($QtiteFlixotideTotal+$QtiteFlixotideTotal1M-$StockFlixotide+$AddStockFlixotide))

if [ $QtiteFlixotideDef -le 0 ]
	then QtiteFlixotideDef=0
fi

QtiteVentolineDef=$(($QtiteVentolineTotal+$QtiteVentolineTotal1M-$StockVentoline+$AddStockVentoline))

if [ $QtiteVentolineDef -le 0 ]
	then QtiteVentolineDef=0
fi


echo -e "\n#######################################################################"
echo -e "Ordonance à faire:"
echo -e "------------------------------------------------------------------------"
echo -e "* $QtiteAnapenDef Anapen      \t(dont 	$QtiteAnapenTotal1M DLC < 1 mois 	et $AddStockAnapen stock)"
echo -e "* $QtiteSolupredDef Solupred     \t(dont 	$QtiteSolupredTotal1M DLC < 1 mois 	et $AddStockSolupred stock)"
echo -e "* $QtiteDesloratadineDef Desloratadine \t(dont 	$QtiteDesloratadineTotal1M DLC < 1 mois 	et $AddStockDesloratadine stock)"
echo -e "* $QtiteFlixotideDef Flixotide     \t(dont 	$QtiteFlixotideTotal1M DLC < 1 mois 	et $AddStockFlixotide stock)"
echo -e "* $QtiteVentolineDef Ventoline     \t(dont 	$QtiteVentolineTotal1M DLC < 1 mois 	et $AddStockVentoline stock)"


echo -e "\n#######################################################################"
echo -e "Veuillez prendre RDV avec le Docteur Delaet." && echo -e "Telephone Secretariat : 01 39 12 21 31" && echo -e "https://www.doctolib.fr/medecin-generaliste/maisons-laffitte/caroline-delaet"


sleep 6d
