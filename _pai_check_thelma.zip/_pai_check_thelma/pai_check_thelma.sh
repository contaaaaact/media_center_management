#!/bin/bash
# Verifier le stock et la date limite de consommation des médicaments du PAI

DateToday=`date +%Y-%m-%d`

echo -e "Nous sommes le :"
date +%Y-%m-%d

echo -e "\nVoici l'état du PAI de Thelma"

StockAnapen=`sed -n 5p /mnt/pi/demetrius/_pai_check_thelma/anapen`
StockCelestene=`sed -n 5p /mnt/pi/demetrius/_pai_check_thelma/celestene`
StockDesloratadine=`sed -n 5p /mnt/pi/demetrius/_pai_check_thelma/desloratadine`
StockFlixotide=`sed -n 5p /mnt/pi/demetrius/_pai_check_thelma/flixotide`
StockVentoline=`sed -n 5p /mnt/pi/demetrius/_pai_check_thelma/ventoline`

DLCAnapenEcole=`sed -n 9p /mnt/pi/demetrius/_pai_check_thelma/anapen`
DLCCelesteneEcole=`sed -n 9p /mnt/pi/demetrius/_pai_check_thelma/celestene`
DLCDesloratadineEcole=`sed -n 9p /mnt/pi/demetrius/_pai_check_thelma/desloratadine`
DLCFlixotideEcole=`sed -n 9p /mnt/pi/demetrius/_pai_check_thelma/flixotide`
DLCVentolineEcole=`sed -n 9p /mnt/pi/demetrius/_pai_check_thelma/ventoline`

DLCAnapenCentre=`sed -n 12p /mnt/pi/demetrius/_pai_check_thelma/anapen`
DLCCelesteneCentre=`sed -n 12p /mnt/pi/demetrius/_pai_check_thelma/celestene`
DLCDesloratadineCentre=`sed -n 12p /mnt/pi/demetrius/_pai_check_thelma/desloratadine`
DLCFlixotideCentre=`sed -n 12p /mnt/pi/demetrius/_pai_check_thelma/flixotide`
DLCVentolineCentre=`sed -n 12p /mnt/pi/demetrius/_pai_check_thelma/ventoline`

DLCAnapenMaison=`sed -n 15p /mnt/pi/demetrius/_pai_check_thelma/anapen`
DLCCelesteneMaison=`sed -n 15p /mnt/pi/demetrius/_pai_check_thelma/celestene`
DLCDesloratadineMaison=`sed -n 15p /mnt/pi/demetrius/_pai_check_thelma/desloratadine`
DLCFlixotideMaison=`sed -n 15p /mnt/pi/demetrius/_pai_check_thelma/flixotide`
DLCVentolineMaison=`sed -n 15p /mnt/pi/demetrius/_pai_check_thelma/ventoline`

# listing du stock

echo -e "\n-----------------------------------------"
echo -e " * STOCK"
echo -e "-----------------------------------------"
echo -e "Anapen  \t$StockAnapen"
echo -e "Celestene \t$StockCelestene"
echo -e "Desloratadine \t$StockDesloratadine"
echo -e "Flixotide \t$StockFlixotide"
echo -e "Ventoline \t$StockVentoline"

# listing DLC

echo -e "\n-----------------------------------------"
echo -e " * DATE LIMITE DE CONSOMMATION"
echo -e "-----------------------------------------"
echo -e "              \tEcole         \tCentre  \tMaison"
echo -e "Anapen  \t$DLCAnapenEcole\t$DLCAnapenCentre\t$DLCAnapenMaison"
echo -e "Celestene \t$DLCCelesteneEcole\t$DLCCelesteneCentre\t$DLCCelesteneMaison"
echo -e "Desloratadine \t$DLCDesloratadineEcole\t$DLCDesloratadineCentre\t$DLCDesloratadineMaison"
echo -e "Flixotide \t$DLCFlixotideEcole\t$DLCFlixotideCentre\t$DLCFlixotideMaison"
echo -e "Ventoline \t$DLCVentolineEcole\t$DLCVentolineCentre\t$DLCVentolineMaison"

# pointage des defauts stock

if [ $StockAnapen -lt 1 -o $StockCelestene -lt 1 -o $StockDesloratadine -lt 1 -o $StockFlixotide -lt 1 -o $StockVentoline -lt 1 ]
	then
		echo -e "\n#######################################################################"
		echo -e "   ATTENTION ! Il n'y a plus de stock pour les medicaments suivants:"
		echo -e "------------------------------------------------------------------------"
		
		
		if [ $StockAnapen -lt 1 ]
			then
				echo -e "* Anapen"
		fi  

		if [ $StockCelestene -lt 1 ]
			then
				echo -e "* Celestene"
		fi

		if [ $StockDesloratadine -lt 1 ]
			then
				echo -e "* Desloratadine"
		fi

		if [ $StockFlixotide -lt 1 ]
			then
				echo -e "* Flixotide"
		fi

		if [ $StockVentoline -lt 1 ]
			then
				echo -e "* Ventoline"
		fi
		
		#echo -e "#######################################################################"
		#echo -e "\nVeuillez prendre RDV avec le Docteur Delaet." && echo -e "Telephone Secretariat : 01 39 12 21 31" && echo -e "https://www.doctolib.fr/medecin-generaliste/maisons-laffitte/caroline-delaet"
        
	else
		echo -e "\n#######################################################################"
		echo -e "Le stock de médicament est suffisant."
		
fi


# pointage des defauts DLC

if [[ $DateToday > $DLCAnapenEcole ]] || [[ $DateToday > $DLCAnapenCentre ]] || [[ $DateToday > $DLCAnapenMaison ]] || [[ $DateToday > $DLCCelesteneEcole ]] || [[ $DateToday > $DLCCelesteneCentre ]] || [[ $DateToday > $DLCCelesteneMaison ]] || [[ $DateToday > $DLCDesloratadineEcole ]] || [[ $DateToday > $DLCDesloratadineCentre ]] || [[ $DateToday > $DLCDesloratadineMaison ]] || [[ $DateToday > $DLCFlixotideEcole ]] || [[ $DateToday > $DLCFlixotideCentre ]] || [[ $DateToday > $DLCFlixotideMaison ]] || [[ $DateToday > $DLCVentolineEcole ]] || [[ $DateToday > $DLCVentolineCentre ]] || [[ $DateToday > $DLCVentolineMaison ]]
	then
		echo -e "\n#######################################################################"
		echo -e "   ATTENTION ! Les médicaments suivants sont périmés:"
		echo -e "------------------------------------------------------------------------"

		QtiteAnapenEcole=0
		QtiteAnapenCentre=0
		QtiteAnapenMaison=0
		QtiteCelesteneEcole=0
		QtiteCelesteneCentre=0
		QtiteCelesteneMaison=0
		QtiteDesloratadineEcole=0
		QtiteDesloratadineCentre=0
		QtiteDesloratadineMaison=0
		QtiteFlixotideEcole=0
		QtiteFlixotideCentre=0
		QtiteFlixotideMaison=0
		QtiteVentolineEcole=0
		QtiteVentolineCentre=0
		QtiteVentolineMaison=0

		if [[ $DateToday > $DLCAnapenEcole ]]
			then
				 echo -e "* Anapen Ecole"
				 QtiteAnapenEcole=1
		fi

		if [[ $DateToday > $DLCAnapenCentre ]]
			then
				 echo -e "* Anapen Centre"
				 QtiteAnapenCentre=1
		fi
				 
		if [[ $DateToday > $DLCAnapenMaison ]]
			then
				 echo -e "* Anapen Maison"
				 QtiteAnapenMaison=1
		fi
		
		if [[ $DateToday > $DLCCelesteneEcole ]]
			then
				 echo -e "* Celestene Ecole"
				 QtiteCelesteneEcole=1
		fi

		if [[ $DateToday > $DLCCelesteneCentre ]]
			then
				 echo -e "* Celestene Centre"
				 QtiteCelesteneCentre=1
		fi
				 
		if [[ $DateToday > $DLCCelesteneMaison ]]
			then
				 echo -e "* Celestene Maison"
				 QtiteCelesteneMaison=1
		fi
		
		if [[ $DateToday > $DLCDesloratadineEcole ]]
			then
				 echo -e "* Desloratadine Ecole"
				 QtiteDesloratadineEcole=1
		fi

		if [[ $DateToday > $DLCDesloratadineCentre ]]
			then
				 echo -e "* Desloratadine Centre"
				 QtiteDesloratadineCentre=1
		fi
				 
		if [[ $DateToday > $DLCDesloratadineMaison ]]
			then
				 echo -e "* Desloratadine Maison"
				 QtiteDesloratadineMaison=1
		fi
		
		if [[ $DateToday > $DLCFlixotideEcole ]]
			then
				 echo -e "* Flixotide Ecole"
				 QtiteFlixotideEcole=1
		fi

		if [[ $DateToday > $DLCFlixotideCentre ]]
			then
				 echo -e "* Flixotide Centre"
				 QtiteFlixotideCentre=1
		fi
				 
		if [[ $DateToday > $DLCFlixotideMaison ]]
			then
				 echo -e "* Flixotide Maison"
				 QtiteFlixotideMaison=1
		fi
		
		if [[ $DateToday > $DLCVentolineEcole ]]
			then
				 echo -e "* Ventoline Ecole"
				 QtiteVentolineEcole=1
		fi

		if [[ $DateToday > $DLCVentolineCentre ]]
			then
				 echo -e "* Ventoline Centre"
				 QtiteVentolineCentre=1
		fi
				 
		if [[ $DateToday > $DLCVentolineMaison ]]
			then
				 echo -e "* Ventoline Maison"
				 QtiteVentolineMaison=1
		fi
		
		QtiteAnapenTotal=$(($QtiteAnapenEcole+$QtiteAnapenCentre+$QtiteAnapenMaison))
		QtiteCelesteneTotal=$(($QtiteCelesteneEcole+$QtiteCelesteneCentre+$QtiteCelesteneMaison))
		QtiteDesloratadineTotal=$(($QtiteDesloratadineEcole+$QtiteDesloratadineCentre+$QtiteDesloratadineMaison))
		QtiteFlixotideTotal=$(($QtiteFlixotideEcole+$QtiteFlixotideCentre+$QtiteFlixotideMaison))
		QtiteVentolineTotal=$(($QtiteVentolineEcole+$QtiteVentolineCentre+$QtiteVentolineMaison))
		
		echo -e "\n#######################################################################"
		echo -e "Ordonance à faire :"
		echo -e "------------------------------------------------------------------------"
		echo -e "* $(($QtiteAnapenTotal-$StockAnapen)) Anapen (+1 si besoin stock)"
		echo -e "* $(($QtiteCelesteneTotal-$StockCelestene)) Celestene (+1 si besoin stock)"
		echo -e "* $(($QtiteDesloratadineTotal-$StockDesloratadine)) Desloratadine (+1 si besoin stock)"
		echo -e "* $(($QtiteFlixotideTotal-$StockFlixotide)) Flixotide (+1 si besoin stock)"
		echo -e "* $(($QtiteVentolineTotal-$StockVentoline)) Ventoline (+1 si besoin stock)"

		
		echo -e "\n#######################################################################"
		echo -e "Veuillez prendre RDV avec le Docteur Delaet." && echo -e "Telephone Secretariat : 01 39 12 21 31" && echo -e "https://www.doctolib.fr/medecin-generaliste/maisons-laffitte/caroline-delaet"
		
else
	echo -e "\n#######################################################################"
	echo -e "Auncun médicament n'est périmé."

fi

sleep 1d
